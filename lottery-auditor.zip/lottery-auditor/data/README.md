# Data Directory

CSV files downloaded by the Data Manager are saved here at runtime.
These files are gitignored since they can be re-downloaded at any time.
