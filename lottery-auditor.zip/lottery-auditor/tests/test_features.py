"""
Unit tests for the lottery tool's feature engineering and data validation.
Run with: pytest tests/test_features.py -v
"""

import sys
import os
import pytest
import numpy as np
import pandas as pd

# Add parent directory to path so we can import the main module
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


def make_fake_lottery_df(n_draws=50, max_main=47, max_mega=27):
    """Generate a synthetic lottery DataFrame for testing."""
    rng = np.random.RandomState(42)
    rows = []
    for i in range(n_draws):
        nums = sorted(rng.choice(range(1, max_main + 1), size=5, replace=False))
        mega = rng.randint(1, max_mega + 1)
        rows.append({
            "Draw Date": pd.Timestamp("2020-01-01") + pd.Timedelta(days=i * 3),
            "Num1": nums[0], "Num2": nums[1], "Num3": nums[2],
            "Num4": nums[3], "Num5": nums[4],
            "Mega": mega,
        })
    df = pd.DataFrame(rows)
    df["Numbers"] = df[["Num1", "Num2", "Num3", "Num4", "Num5"]].values.tolist()
    df["MegaBall"] = df["Mega"]
    return df


class TestFeatureEngineering:
    """Tests for the _build_features function."""

    def test_build_features_shape(self):
        from Lottery_Tool import _build_features
        df = make_fake_lottery_df(n_draws=50)
        ml_df, df_binary, last_seen = _build_features(df, max_main=47, max_mega=27)

        # df_binary should have one row per draw, one column per number
        assert df_binary.shape == (50, 47)

        # ml_df should have rows for draws 10 through 48 (inclusive), for each of 47 numbers
        expected_rows = (50 - 1 - 10) * 47  # (draws 10..48) * 47 numbers
        assert len(ml_df) == expected_rows

        # Check required columns exist
        for col in ["Number", "Gap", "Freq_Last_10", "Freq_Last_3", "Target"]:
            assert col in ml_df.columns

    def test_gap_is_nonnegative(self):
        from Lottery_Tool import _build_features
        df = make_fake_lottery_df(n_draws=50)
        ml_df, _, _ = _build_features(df, max_main=47, max_mega=27)
        assert (ml_df["Gap"] >= 0).all()

    def test_freq_last_10_bounded(self):
        from Lottery_Tool import _build_features
        df = make_fake_lottery_df(n_draws=50)
        ml_df, _, _ = _build_features(df, max_main=47, max_mega=27)
        # A number can appear at most once per draw, so max freq in 10 draws = 10
        assert (ml_df["Freq_Last_10"] <= 10).all()
        assert (ml_df["Freq_Last_10"] >= 0).all()

    def test_freq_last_3_bounded(self):
        from Lottery_Tool import _build_features
        df = make_fake_lottery_df(n_draws=50)
        ml_df, _, _ = _build_features(df, max_main=47, max_mega=27)
        assert (ml_df["Freq_Last_3"] <= 3).all()
        assert (ml_df["Freq_Last_3"] >= 0).all()

    def test_target_is_binary(self):
        from Lottery_Tool import _build_features
        df = make_fake_lottery_df(n_draws=50)
        ml_df, _, _ = _build_features(df, max_main=47, max_mega=27)
        assert set(ml_df["Target"].unique()).issubset({0, 1})

    def test_binary_matrix_row_sums(self):
        from Lottery_Tool import _build_features
        df = make_fake_lottery_df(n_draws=50)
        _, df_binary, _ = _build_features(df, max_main=47, max_mega=27)
        # Each draw picks exactly 5 numbers
        row_sums = df_binary.sum(axis=1)
        assert (row_sums == 5).all()


class TestTrainAndPredict:
    """Integration test for the full train/predict pipeline."""

    def test_returns_valid_predictions(self):
        from Lottery_Tool import train_and_predict
        df = make_fake_lottery_df(n_draws=80, max_main=47, max_mega=27)
        top_5, mega, prob_df, backtest = train_and_predict(df, 47, 27)

        # Should return exactly 5 main numbers
        assert len(top_5) == 5
        # All numbers in valid range
        assert all(1 <= n <= 47 for n in top_5)
        # No duplicates
        assert len(set(top_5)) == 5
        # Mega in valid range
        assert 1 <= mega <= 27

    def test_backtest_has_required_keys(self):
        from Lottery_Tool import train_and_predict
        df = make_fake_lottery_df(n_draws=80, max_main=47, max_mega=27)
        _, _, _, backtest = train_and_predict(df, 47, 27)

        for key in ["accuracy", "precision", "baseline_hit_rate", "test_samples"]:
            assert key in backtest

    def test_probabilities_sum_reasonable(self):
        from Lottery_Tool import train_and_predict
        df = make_fake_lottery_df(n_draws=80, max_main=47, max_mega=27)
        _, _, prob_df, _ = train_and_predict(df, 47, 27)

        # All probabilities between 0 and 1
        assert (prob_df["Probability"] >= 0).all()
        assert (prob_df["Probability"] <= 1).all()
        # Should have one row per number
        assert len(prob_df) == 47


class TestDateParsing:
    """Tests for the date parsing helper."""

    def test_standard_date(self):
        from Lottery_Tool import _parse_date_tuple
        result = _parse_date_tuple("01/15/2024")
        assert result == ("2024", "01", "15")

    def test_date_with_day_name(self):
        from Lottery_Tool import _parse_date_tuple
        result = _parse_date_tuple("Tuesday 03/10/2026")
        assert result == ("2026", "03", "10")

    def test_date_sorting_order(self):
        from Lottery_Tool import _parse_date_tuple
        dates = ["12/31/2023", "01/01/2024", "06/15/2023"]
        sorted_dates = sorted(dates, key=_parse_date_tuple)
        assert sorted_dates == ["06/15/2023", "12/31/2023", "01/01/2024"]


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
